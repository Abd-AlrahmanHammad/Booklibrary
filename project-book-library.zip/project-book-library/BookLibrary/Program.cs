﻿using BookLibrary.Models;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// جلسات وذاكرة وسطية (كما كانت)
builder.Services.AddMemoryCache();
builder.Services.AddSession();

// ❶ ربط DbContext بالخيط "LibraryContext"
builder.Services.AddDbContext<LibraryContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("LibraryContext")));

builder.Services.AddControllersWithViews();

var app = builder.Build();

// ❷ تطبيق الـ Migrations أوّلاً بأوّل
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<LibraryContext>();
    db.Database.Migrate();     // بدلاً من Migrate() يمكنك استخدام EnsureCreated() إذا لا تريد مigrations
}

// إعداد أنبوب الطلبات HTTP
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}

app.UseStaticFiles();
app.UseRouting();
app.UseSession();
app.UseAuthorization();

// مسار افتراضي يوجّه إلى صفحة LogIn
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=LogIn}/{action=LogIn}/{id?}");

app.Run();
